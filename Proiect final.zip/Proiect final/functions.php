<?php
function conectare($titlu_pagina){
  global $link;
  $host = 'localhost';
  $user = 'root';
  $passwd = '';
  $schema = 'biblioteca';
  $link = @mysqli_connect($host, $user, $passwd, $schema);
  $output = "<!DOCTYPE HTML><head><title>$titlu_pagina</title><link rel='stylesheet' type='text/css' href='style.css' /><link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet'></head><body>";
  /* Check if the connection succeeded */
  if (!$link)
  {
    $output .= '<font color=red>Conectarea la baza de date nu a putut fi efectuata!<br>';
    $output .= 'Numar eroare: ' . mysqli_connect_errno() . '<br>';
    $output .= 'Mesaj eroare: ' . mysqli_connect_error() . '<br></font>';
    echo $output;
    return false;
  } else {
    $output .= '<font color=green>Conectarea la baza de date a fost efectuata cu succes!</font><br>';
    echo $output;
    return true;
  }
}

function popup($text_popup){
    return "<script language='javascript'>alert('$text_popup')</script>";
}
function deconectare(){
  global $link; 
  mysqli_close($link);
}

function echo_sql($query,$print){
  global $link;
  if ($print == True){
      return "<font color=black><pre>SE EXECUTA QUERY-ul: \t".$query."</pre></font>";
  }
}

function afisare_tabel_autor($sql = "SELECT * FROM AUTOR;"){
  global $link;
  $output = '';
  $output .= echo_sql($sql,true);
  if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
        $output .= "<table border=1>";
            $output .=  "<tr>";
                  $output .=  "<th>ID AUTOR</th>";
                  $output .=  "<th>NUME</th>";
                  $output .=  "<th>PRENUME</th>";
                  $output .=  "<th>DATA NASTERE</th>";
                  $output .=  "<th>DATA DECES</th>";
                  $output .=  "<th>DESCRIERE</th>";
              $output .=  "</tr>";
          while($row = mysqli_fetch_array($result)){
              $output .=  "<tr>";
                  $output .=  "<td>" . $row['id_autor'] . "</td>";
                  $output .=  "<td>" . $row['nume'] . "</td>";
                  $output .=  "<td>" . $row['prenume'] . "</td>";
                  $output .=  "<td>" . $row['data_nastere'] . "</td>";
                  $output .=  "<td>" . $row['data_deces'] . "</td>";
                  $output .=  "<td>" . $row['descriere'] . "</td>";
              $output .=  "</tr>";
          }
          $output .=  "</table>";
          // Free result set
          mysqli_free_result($result);
      } else{
        $output .=  "Nu s-au gasit inregistrari in tabela AUTOR care sa se potriveasca selectiei tale.";
    }
} else{
    $output .=  "Eroare: nu s-a putut executa $sql. " . mysqli_error($link);
}
return $output;}



function afisare_tabel_editura($sql = "SELECT * FROM EDITURA;"){
  global $link;
  $output = '';
  $output .= echo_sql($sql,true);
  if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
          $output .= "<table border=1>";
              $output .= "<tr>";
                  $output .= "<th>ID EDITURA</th>";
                  $output .= "<th>NUME EDITURA</th>";
                  $output .= "<th>ADRESA</th>";
              $output .= "</tr>";
          while($row = mysqli_fetch_array($result)){
              $output .= "<tr>";
                  $output .= "<td>" . $row['id_editura'] . "</td>";
                  $output .= "<td>" . $row['nume_editura'] . "</td>";
                  $output .= "<td>" . $row['adresa'] . "</td>";
              $output .= "</tr>";
          }
          $output .= "</table>";
          // Free result set
          mysqli_free_result($result);
      } else{
        $output .= "Nu s-au gasit inregistrari in tabela EDITURA care sa se potriveasca selectiei tale.";
    }
} else{
    $output .= "Eroare: nu s-a putut executa $sql. " . mysqli_error($link);
}
return $output;}

function afisare_tabel_carte($sql = "SELECT carte.id_carte, carte.ISBN, carte.titlu, carte.an_aparitie, carte.numar_carti_disponibile, categorie.tip_categorie, editura.nume_editura,
concat_ws(' ',autor.nume,autor.prenume) as nume_autor FROM carte JOIN autor using (id_autor) join editura USING (id_editura) join categorie USING (id_categorie) order by carte.titlu;"){
  global $link;
  $output = '';
  $output .= echo_sql($sql,true);
  if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
          $output .=   "<table border=1>";
              $output .=   "<tr>";
                  $output .= "<th>ID CARTE</th>";
                  $output .= "<th>ISBN</th>";
                  $output .= "<th>TITLU</th>";
                  $output .= "<th>AN APARITIE</th>";
                  $output .= "<th>NUMAR CARTI DISPONIBILE</th>";
                  $output .= "<th>CATEGORIE</th>";
                  $output .= "<th>AUTOR</th>";
                  $output .= "<th>EDITURA</th>";                  
              $output .= "</tr>";
          while($row = mysqli_fetch_array($result)){
              $output .= "<tr>";
                  $output .= "<td>" . $row['id_carte'] . "</td>";
                  $output .= "<td>" . $row['ISBN'] . "</td>";
                  $output .= "<td>" . $row['titlu'] . "</td>";
                  $output .= "<td>" . $row['an_aparitie'] . "</td>";
                  $output .= "<td>" . $row['numar_carti_disponibile'] . "</td>";
                  $output .= "<td>" . $row['tip_categorie'] . "</td>";
                  $output .= "<td>" . $row['nume_autor'] . "</td>";
                  $output .= "<td>" . $row['nume_editura'] . "</td>";                  
              $output .=  "</tr>";
          }
          $output .=   "</table>";
          // Free result set
          mysqli_free_result($result);
      } else{
        $output .= "Nu s-au gasit inregistrari in tabela CARTE care sa se potriveasca selectiei tale.";
    }
} else{
    $output .= "Eroare: nu s-a putut executa $sql. " . mysqli_error($link);
}
return $output;}


function afisare_tabel_imprumut($sql = "SELECT imprumut.id_imprumut, imprumut.data_imprumut, imprumut.durata_imprumut, concat_ws(' ',cititor.nume,cititor.prenume) as nume_cititor,
 carte.titlu FROM IMPRUMUT join CITITOR using (id_cititor) join CARTE using (id_carte) order by durata_imprumut;"){
  global $link;
  $output = '';
  $output .= echo_sql($sql,true);
  if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
          $output .= "<table border=1>";
              $output .= "<tr>";
                  $output .= "<th>ID IMPRUMUT</th>";
                  $output .= "<th>DATA IMPRUMUT</th>";
                  $output .= "<th>DURATA IMPRUMUT INITIAL (zile)</th>";
                  $output .= "<th>NUME CITITOR</th>";
                  $output .= "<th>CARTE</th>";                 
              $output .= "</tr>";
          while($row = mysqli_fetch_array($result)){
            $diferenta = abs(strtotime(date(date('Y-m-d'))) - strtotime(date($row['data_imprumut'])))/86400;//86400 secunde intr-o zi
            if ($diferenta >= 30){
                $output .= "<tr class='alert'>";
            } else {
                $output .= "<tr class='ok'>";
            }

                  $output .= "<td>" . $row['id_imprumut'] . "</td>";
                  $output .= "<td>" . $row['data_imprumut'] . "</td>";
                  $output .= "<td>" . $row['durata_imprumut'] . "</td>";
                  $output .= "<td>" . $row['nume_cititor']."</td>";
                  $output .= "<td>" . $row['titlu']. "</td>";                
              $output .= "</tr>";
          }
          $output .= "</table>";
          // Free result set
          mysqli_free_result($result);
      } else{
        $output .= "Nu s-au gasit inregistrari in tabela IMPRUMUT care sa se potriveasca selectiei tale.";
    }
} else{
    $output .= "Eroare: nu s-a putut executa $sql. " . mysqli_error($link);
}
return $output;}

function afisare_tabel_cititor($sql = "SELECT cititor.id_cititor, cititor.cnp, concat_ws(' ',cititor.nume,cititor.prenume) as nume_cititor, cititor.telefon, cititor.e_mail, 
companie.nume_companie FROM CITITOR join companie using (id_companie) order by cititor.nume;"){
  global $link;
  $output = '';
  $output .= echo_sql($sql,true);
  if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
          $output .= "<table border=1>";
              $output .= "<tr>";
                  $output .= "<th>ID CITITOR</th>";
                  $output .= "<th>CNP</th>";
                  $output .= "<th>NUME si PRENUME</th>";
                  $output .= "<th>TELEFON</th>";
                  $output .= "<th>E-mail</th>";
                  $output .= "<th>Companie</th>";
              $output .= "</tr>";
          while($row = mysqli_fetch_array($result)){
              $output .= "<tr>";
                  $output .= "<td>" . $row['id_cititor'] . "</td>";
                  $output .= "<td>" . $row['cnp'] . "</td>";
                  $output .= "<td>" . $row['nume_cititor'] . "</td>";
                  $output .= "<td>" . $row['telefon'] . "</td>";
                  $output .= "<td>" . $row['e_mail'] . "</td>";
                  $output .= "<td>" . $row['nume_companie'] . "</td>";
              $output .= "</tr>";
          }
          $output .= "</table>";
          // Free result set
          mysqli_free_result($result);
      } else{
        $output .= "Nu s-au gasit inregistrari in tabela CITITOR care sa se potriveasca selectiei tale.";
    }
} else{
    $output .= "Eroare: nu s-a putut executa $sql. " . mysqli_error($link);
}
return $output;}


function afisare_tabel_categorie($sql = "SELECT * FROM CATEGORIE;"){
    global $link;
    $output = '';
    $output .= echo_sql($sql,true);
    if($result = mysqli_query($link, $sql)){
        if(mysqli_num_rows($result) > 0){
            $output .= "<table border=1>";
                $output .= "<tr>";
                    $output .= "<th>ID CATEGORIE</th>";
                    $output .= "<th>TIP CATEGORIE</th>";
                $output .= "</tr>";
            while($row = mysqli_fetch_array($result)){
                $output .= "<tr>";
                    $output .= "<td>" . $row['id_categorie'] . "</td>";
                    $output .= "<td>" . $row['tip_categorie'] . "</td>";             
                $output .= "</tr>";
            }
            $output .= "</table>";
            // Free result set
            mysqli_free_result($result);
        } else{
          $output .= "Nu s-au gasit inregistrari in tabela CATEGORIE care sa se potriveasca selectiei tale.";
      }
  } else{
      $output .= "Eroare: nu s-a putut executa $sql. " . mysqli_error($link);
  }
  return $output;}


  function afisare_tabel_companie($sql = "SELECT * FROM COMPANIE;"){
    global $link;
    $output = '';
    $output .= echo_sql($sql,true);
    if($result = mysqli_query($link, $sql)){
        if(mysqli_num_rows($result) > 0){
            $output .= "<table border=1>";
                $output .= "<tr>";
                    $output .= "<th>ID COMPANIE</th>";
                    $output .= "<th>NUME COMPANIE</th>";
                $output .= "</tr>";
            while($row = mysqli_fetch_array($result)){
                $output .= "<tr>";
                    $output .= "<td>" . $row['id_companie'] . "</td>";
                    $output .= "<td>" . $row['nume_companie'] . "</td>";             
                $output .= "</tr>";
            }
            $output .= "</table>";
            // Free result set
            mysqli_free_result($result);
        } else{
          $output .= "Nu s-au gasit inregistrari in tabela COMPANIE care sa se potriveasca selectiei tale.";
      }
  } else{
      $output .= "Eroare: nu s-a putut executa $sql. " . mysqli_error($link);
  }
  return $output;}

  
function rulare_si_afisare_query($cerinta,$sql,$varianta){
    global $link;
    $output = "";
    if ($varianta == true) {//daca este true, inseamna ca este cerinta din proiect, altfel este comentariul meu
        $output .= "<font color=black>&#9830 Cerinta: ".$cerinta."<br></font>";
    } else {
        $output .= "<font color=black>&#9724 Comentariul meu: ".$cerinta."<br></font>";
    }
    $output .= "Se executa query-ul: <pre>".$sql."</pre>";
    
    $result = mysqli_query($link, $sql);
    if ($result === true){
        $output .= "<font color=green>Instructiunea s-a executat cu succes.</font><br><br><hr>";
    } elseif ($result === false){
        $output .= "<font color=red>Instructiunea nu s-a executat cu succes.</font><br><br><hr>";
    } else{
        $output .= "<font color=green>Instructiunea s-a executat cu succes si a returnat rezultatul din tabel.</font><br><TABLE>";
        if(mysqli_num_rows($result) > 0){
            $cap_tabel = mysqli_fetch_fields($result);
            foreach ($cap_tabel as $coloana) {
                $output .= "<TH>".(strtoupper($coloana -> name))."</TH>";
              }
            while($row =  mysqli_fetch_row($result)){
                $output .= "<TR>";
                foreach($row as $randtabel){
                    $output .= "<TD>".$randtabel."</TD>";
                }
                $output .= "</TR>";
            }
            mysqli_free_result($result);}
        $output .="</TABLE><BR><HR>";}
    return $output;}
  
  function creare_db(){
    $output = '';
    $cerinta = "Stergere baza de date daca aceasta exista.";
    $sql = "DROP DATABASE IF EXISTS biblioteca;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);

    $cerinta = "Creare baza de date.";
    $sql = "CREATE DATABASE biblioteca;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    $cerinta = "Folosire baza de date.";
    $sql = "USE biblioteca;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);

    return $output;
  }
  
  function creare_tabele(){
    $output = '';
    
    $cerinta = "Creare tabel autor.";
    $sql = "CREATE TABLE autor (
        id_autor int NOT NULL AUTO_INCREMENT,
        nume varchar(45) NOT NULL,
        prenume varchar(45) NOT NULL,
        data_nastere INT NOT NULL,
        data_deces INT NULL,
        descriere varchar(400) DEFAULT 'fara descriere',
        PRIMARY KEY (id_autor)
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    $cerinta = "Creare tabel categorii.";
    $sql = "CREATE TABLE categorie (
        id_categorie int NOT NULL AUTO_INCREMENT,
        tip_categorie varchar(30) NOT NULL,
        PRIMARY KEY (id_categorie)
        ) ENGINE=InnoDB  DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Creare tabel editura.";
    $sql = "CREATE TABLE editura (
        id_editura int NOT NULL AUTO_INCREMENT,
        nume_editura varchar(45) NOT NULL,
        adresa varchar(100) NULL,
        PRIMARY KEY (id_editura)
        ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Creare tabel carte.";
    $sql = "CREATE TABLE carte (
        id_carte int NOT NULL AUTO_INCREMENT,
        ISBN VARCHAR(13) NOT NULL,
        titlu varchar(60) NOT NULL,
        an_aparitie year(4) NOT NULL,
        numar_carti_disponibile int NOT NULL,
        id_categorie int NOT NULL,
        id_autor int NOT NULL,
        id_editura int NOT NULL,
        PRIMARY KEY (id_carte),
        FOREIGN KEY (id_categorie) REFERENCES categorie (id_categorie),
        FOREIGN KEY (id_autor) REFERENCES autor (id_autor),
        FOREIGN KEY (id_editura) REFERENCES editura (id_editura)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Creare tabel companie.";
    $sql = "CREATE TABLE companie (
        id_companie int NOT NULL AUTO_INCREMENT,
        nume_companie varchar(30) NOT NULL,
        PRIMARY KEY (id_companie)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Creare tabel cititor.";
    $sql = "CREATE TABLE cititor (
        id_cititor int NOT NULL AUTO_INCREMENT,
        cnp varchar(13) NOT NULL unique,
        nume varchar(45) NOT NULL,
        prenume varchar(45) NOT NULL,
        telefon varchar(15) NULL,
        e_mail varchar(40)  NULL,
        id_companie int NULL,
        PRIMARY KEY (id_cititor),
        FOREIGN KEY (id_companie) REFERENCES companie (id_companie)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Creare tabel imprumut.";
    $sql = "CREATE TABLE imprumut (
        id_imprumut int NOT NULL AUTO_INCREMENT,
        data_imprumut date NOT NULL,
        durata_imprumut int NOT NULL,
        id_cititor int NOT NULL,
        id_carte int NOT NULL,
        PRIMARY KEY (id_imprumut),
        FOREIGN KEY (id_cititor) REFERENCES cititor (id_cititor),
        FOREIGN KEY (id_carte) REFERENCES carte (id_carte)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);

    return $output;}
  
  function creare_tabele_tracking(){
    $output = '';

    $cerinta = "Creare tabel autor_tracking, pentru a avea un istoric asupra oricarei operatiuni de insert, delete, update pe tabelul autor.";
    $sql = "CREATE TABLE autor_tracking (
        id_autor_tracking INT AUTO_INCREMENT,
        new_id_autor INT,
        old_id_autor INT,
        new_nume varchar(45),
        old_nume varchar(45),
        new_prenume varchar(45),
        old_prenume varchar(45),
        new_data_nastere INT,
        old_data_nastere INT,
        new_data_deces INT,
        old_data_deces INT,
        new_descriere varchar(400),
        old_descriere varchar(400),
        persoana VARCHAR(20),
        change_DATE DATETIME,
        operatiune VARCHAR(10),
        PRIMARY KEY (id_autor_tracking)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);

    $cerinta = "Creare tabel categorie_tracking, pentru a avea un istoric asupra oricarei operatiuni de insert, delete, update pe tabelul categorie.";
    $sql = "CREATE TABLE categorie_tracking (
        id_categorie_tracking INT AUTO_INCREMENT,
        new_id_categorie int,
        old_id_categorie int,  
        new_tip_categorie varchar(30),
        old_tip_categorie varchar(30),
        persoana VARCHAR(20),
        change_DATE DATETIME,
        operatiune VARCHAR(10),
        PRIMARY KEY (id_categorie_tracking)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);

    $cerinta = "Creare tabel editura_tracking, pentru a avea un istoric asupra oricarei operatiuni de insert, delete, update pe tabelul editura.";
    $sql = "CREATE TABLE editura_tracking (
        id_editura_tracking INT AUTO_INCREMENT,
        new_id_editura INT,
        old_id_editura int,
        new_nume_editura varchar(45),
        old_nume_editura varchar(45),
        new_adresa varchar(100),
        old_adresa varchar(100),
        persoana VARCHAR(20),
        change_DATE DATETIME,
        operatiune VARCHAR(10),
        PRIMARY KEY (id_editura_tracking)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare tabel carte_tracking, pentru a avea un istoric asupra oricarei operatiuni de insert, delete, update pe tabelul carte.";
    $sql = "CREATE TABLE carte_tracking (
        id_carte_tracking INT AUTO_INCREMENT,
        new_id_carte int,
        old_id_carte int,
        new_ISBN VARCHAR(13),
        old_ISBN VARCHAR(13),
        new_titlu varchar(60),
        old_titlu varchar(60),
        new_an_aparitie year(4),
        old_an_aparitie year(4),
        new_numar_carti_disponibile INT,
        old_numar_carti_disponibile int,
        new_id_categorie INT,
        old_id_categorie int,
        new_id_autor INT,
        old_id_autor int,
        new_id_editura INT,
        old_id_editura INT,
        persoana VARCHAR(20),
        change_DATE DATETIME,
        operatiune VARCHAR(10),
        PRIMARY KEY (id_carte_tracking)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare tabel companie_tracking, pentru a avea un istoric asupra oricarei operatiuni de insert, delete, update pe tabelul companie.";
    $sql = "CREATE TABLE companie_tracking (
        id_companie_tracking int AUTO_INCREMENT,
        new_id_companie int,
        old_id_companie int,
        new_nume_companie varchar(30),
        old_nume_companie varchar(30),
        persoana VARCHAR(20),
        change_DATE DATETIME,
        operatiune VARCHAR(10),
        PRIMARY KEY (id_companie_tracking)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;
        ";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare tabel cititor_tracking, pentru a avea un istoric asupra oricarei operatiuni de insert, delete, update pe tabelul cititor.";
    $sql = "CREATE TABLE cititor_tracking (
        id_cititor_tracking INT AUTO_INCREMENT,
        new_id_cititor INT,
        old_id_cititor int,
        new_cnp varchar(13),
        old_cnp varchar(13),
        new_nume varchar(45),
        old_nume varchar(45),
        new_prenume varchar(45),
        old_prenume varchar(45),
        new_telefon varchar(15),
        old_telefon varchar(15),
        new_e_mail varchar(40),
        old_e_mail varchar(40),
        new_id_companie INT,
        old_id_companie INT,
        persoana VARCHAR(20),
        change_DATE DATETIME,
        operatiune VARCHAR(10),
        PRIMARY KEY (id_cititor_tracking)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare tabel imprumut_tracking, pentru a avea un istoric asupra oricarei operatiuni de insert, delete, update pe tabelul imprumut.";
    $sql = "CREATE TABLE imprumut_tracking (
        id_imprumut_tracking int AUTO_INCREMENT,
        new_id_imprumut int,
        old_id_imprumut int,
        new_data_imprumut date,
        old_data_imprumut date,
        new_durata_imprumut int,
        old_durata_imprumut int,
        new_id_cititor INT,
        old_id_cititor int,
        new_id_carte INT,
        old_id_carte int,
        persoana VARCHAR(20),
        change_DATE DATETIME,
        operatiune VARCHAR(10),
        PRIMARY KEY (id_imprumut_tracking)
        ) ENGINE=InnoDB DEFAULT CHARSET=LATIN1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
    
    return $output;}


function creare_triggere(){
    $output = '';

    $cerinta = "Creare trigger insert_autor";
    $sql = "CREATE TRIGGER insert_autor after INSERT ON autor FOR EACH ROW
        begin
        INSERT INTO autor_tracking (new_id_autor, old_id_autor, new_nume, old_nume, new_prenume, old_prenume, new_data_nastere, old_data_nastere,
        new_data_deces, old_data_deces, new_descriere, old_descriere, persoana, change_date, operatiune) 
        VALUES (NEW.id_autor, NULL, NEW.nume, NULL, NEW.prenume, NULL, NEW.data_nastere, NULL, NEW.data_deces, NULL, NEW.descriere, null, USER(), NOW(), 'INSERT');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger delete_autor";
    $sql = "CREATE TRIGGER delete_autor before delete ON autor FOR EACH ROW
        begin
        INSERT INTO autor_tracking (new_id_autor, old_id_autor, new_nume, old_nume, new_prenume, old_prenume, new_data_nastere, old_data_nastere,
        new_data_deces, old_data_deces, new_descriere, old_descriere, persoana, change_date, operatiune) 
        VALUES (NULL, OLD.id_autor, NULL, OLD.nume, NULL, OLD.prenume, NULL, OLD.data_nastere, NULL, OLD.data_deces, null, OLD.descriere, USER(), NOW(), 'DELETE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger update_autor";
    $sql = "CREATE TRIGGER update_autor after update ON autor FOR EACH ROW
        begin
        INSERT INTO autor_tracking (new_id_autor, old_id_autor, new_nume, old_nume, new_prenume, old_prenume, new_data_nastere, old_data_nastere,
        new_data_deces, old_data_deces, new_descriere, old_descriere, persoana, change_date, operatiune) 
        VALUES (NEW.id_autor, OLD.id_autor, NEW.nume, OLD.nume, NEW.prenume, OLD.prenume, NEW.data_nastere, OLD.data_nastere, 
        NEW.data_deces, OLD.data_deces, NEW.descriere, OLD.descriere, USER(), NOW(), 'UPDATE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger insert_categorie";
    $sql = "CREATE TRIGGER insert_categorie after INSERT ON categorie FOR EACH ROW
        begin
        INSERT INTO categorie_tracking (new_id_categorie, old_id_categorie, new_tip_categorie, old_tip_categorie, persoana, change_date, operatiune) 
        VALUES (NEW.id_categorie, NULL, NEW.tip_categorie, NULL, USER(), NOW(), 'INSERT');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger delete_categorie";
    $sql = "CREATE TRIGGER delete_categorie before delete ON categorie FOR EACH ROW
        begin
        INSERT INTO categorie_tracking (new_id_categorie, old_id_categorie, new_tip_categorie, old_tip_categorie, persoana, change_date, operatiune) 
        VALUES (NULL, OLD.id_categorie, NULL, OLD.tip_categorie, USER(), NOW(), 'DELETE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger update_categorie";
    $sql = "CREATE TRIGGER update_categorie after update ON categorie FOR EACH ROW
        begin
        INSERT INTO categorie_tracking (new_id_categorie, old_id_categorie, new_tip_categorie, old_tip_categorie, persoana, change_date, operatiune) 
        VALUES (NEW.id_categorie, OLD.id_categorie, NEW.tip_categorie, OLD.tip_categorie, USER(), NOW(), 'UPDATE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger insert_editura";
    $sql = "CREATE TRIGGER insert_editura after INSERT ON editura FOR EACH ROW
        begin
        INSERT INTO editura_tracking (new_id_editura, old_id_editura, new_nume_editura, old_nume_editura, new_adresa, old_adresa, persoana, change_date, operatiune)
        VALUES (NEW.id_editura, NULL, NEW.nume_editura, NULL, NEW.adresa, NULL, USER(), NOW(), 'INSERT');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger delete_editura";
    $sql = "CREATE TRIGGER delete_editura before delete ON editura FOR EACH ROW
        begin
        INSERT INTO editura_tracking (new_id_editura, old_id_editura, new_nume_editura, old_nume_editura, new_adresa, old_adresa, persoana, change_date, operatiune)
        VALUES (NULL, OLD.id_editura, NULL, OLD.nume_editura, NULL, OLD.adresa, USER(), NOW(), 'DELETE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);

    
    $cerinta = "Creare trigger update_editura";
    $sql = "CREATE TRIGGER update_editura after update ON editura FOR EACH ROW
        begin
        INSERT INTO editura_tracking (new_id_editura, old_id_editura, new_nume_editura, old_nume_editura, new_adresa, old_adresa, persoana, change_date, operatiune)
        VALUES (NEW.id_editura, OLD.id_editura, NEW.nume_editura, OLD.nume_editura, NEW.adresa, OLD.adresa,  USER(), NOW(), 'UPDATE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger insert_carte";
    $sql = "CREATE TRIGGER insert_carte after INSERT ON carte FOR EACH ROW
        begin
        INSERT INTO carte_tracking (id_carte_tracking, new_id_carte, old_id_carte, new_ISBN, old_ISBN, new_titlu, old_titlu, new_an_aparitie, old_an_aparitie, new_numar_carti_disponibile,
        old_numar_carti_disponibile, new_id_categorie, old_id_categorie, new_id_autor, old_id_autor, new_id_editura, old_id_editura, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_carte, NULL, NEW.ISBN, NULL, NEW.titlu, NULL, NEW.an_aparitie, NULL, NEW.numar_carti_disponibile, 
        NULL, NEW.id_categorie, NULL, NEW.id_autor, NULL, NEW.id_editura, NULL, USER(), NOW(), 'INSERT');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger delete_carte";
    $sql = "CREATE TRIGGER delete_carte before delete ON carte FOR EACH ROW
        begin
        INSERT INTO carte_tracking (id_carte_tracking, new_id_carte, old_id_carte, new_ISBN, old_ISBN, new_titlu, old_titlu, new_an_aparitie, old_an_aparitie, new_numar_carti_disponibile,
        old_numar_carti_disponibile, new_id_categorie, old_id_categorie, new_id_autor, old_id_autor, new_id_editura, old_id_editura, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NULL, OLD.id_carte, NULL, OLD.ISBN, NULL, OLD.titlu, NULL, OLD.an_aparitie, NULL, OLD.numar_carti_disponibile, NULL, OLD.id_categorie,
        NULL, OLD.id_autor, NULL, OLD.id_editura, USER(), NOW(), 'DELETE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger update_carte";
    $sql = "CREATE TRIGGER update_carte after update ON carte FOR EACH ROW
        begin
        INSERT INTO carte_tracking (id_carte_tracking, new_id_carte, old_id_carte, new_ISBN, old_ISBN, new_titlu, old_titlu, new_an_aparitie, old_an_aparitie, new_numar_carti_disponibile,
        old_numar_carti_disponibile, new_id_categorie, old_id_categorie, new_id_autor, old_id_autor, new_id_editura, old_id_editura, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_carte, OLD.id_carte, NEW.ISBN, OLD.ISBN, NEW.titlu, OLD.titlu, NEW.an_aparitie, OLD.an_aparitie, NEW.numar_carti_disponibile, OLD.numar_carti_disponibile, 
        NEW.id_categorie, OLD.id_categorie, NEW.id_autor, OLD.id_autor, NEW.id_editura, OLD.id_editura,  USER(), NOW(), 'UPDATE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger insert_companie";
    $sql = "CREATE TRIGGER insert_companie after INSERT ON companie FOR EACH ROW
        begin
        INSERT INTO companie_tracking (id_companie_tracking, new_id_companie, old_id_companie, new_nume_companie, old_nume_companie, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_companie, NULL, NEW.nume_companie, NULL, USER(), NOW(), 'INSERT');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);

    
    $cerinta = "Creare trigger delete_companie";
    $sql = "    CREATE TRIGGER delete_companie before delete ON companie FOR EACH ROW
        begin
        INSERT INTO companie_tracking (id_companie_tracking, new_id_companie, old_id_companie, new_nume_companie, old_nume_companie, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NULL, OLD.id_companie, NULL, OLD.nume_companie, USER(), NOW(), 'DELETE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger update_companie";
    $sql = "    CREATE TRIGGER update_companie after update ON companie FOR EACH ROW
        begin
        INSERT INTO companie_tracking (id_companie_tracking, new_id_companie, old_id_companie, new_nume_companie, old_nume_companie, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_companie, OLD.id_companie, NEW.nume_companie, OLD.nume_companie, USER(), NOW(), 'UPDATE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);    


    $cerinta = "Creare trigger insert_cititor";
    $sql = "CREATE TRIGGER insert_cititor after INSERT ON cititor FOR EACH ROW
        begin
        INSERT INTO cititor_tracking (id_cititor_tracking, new_id_cititor, old_id_cititor, new_cnp, old_cnp,new_nume, old_nume,
        new_prenume, old_prenume, new_telefon, old_telefon, new_e_mail, old_e_mail, new_id_companie, old_id_companie, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_cititor, NULL, NEW.cnp, NULL, NEW.nume, NULL, NEW.prenume, NULL, NEW.telefon, NULL, NEW.e_mail, NULL, NEW.id_companie, NULL, USER(), NOW(), 'INSERT');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);

    
    $cerinta = "Creare trigger delete_cititor";
    $sql = "CREATE TRIGGER delete_cititor before delete ON cititor FOR EACH ROW
        begin
        INSERT INTO cititor_tracking (id_cititor_tracking, new_id_cititor, old_id_cititor, new_cnp, old_cnp,new_nume, old_nume,
        new_prenume, old_prenume, new_telefon, old_telefon, new_e_mail, old_e_mail, new_id_companie, old_id_companie, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NULL, OLD.id_cititor, NULL, OLD.cnp, NULL, OLD.nume, NULL, OLD.prenume, NULL, OLD.telefon, NULL, OLD.e_mail, NULL, OLD.id_companie, USER(), NOW(), 'DELETE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger update_cititor";
    $sql = "CREATE TRIGGER update_cititor after update ON cititor FOR EACH ROW
        begin
        INSERT INTO cititor_tracking (id_cititor_tracking, new_id_cititor, old_id_cititor, new_cnp, old_cnp,new_nume, old_nume,
        new_prenume, old_prenume, new_telefon, old_telefon, new_e_mail, old_e_mail, new_id_companie, old_id_companie, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_cititor, OLD.id_cititor, NEW.cnp, OLD.cnp, NEW.nume, OLD.nume, NEW.prenume, OLD.prenume, NEW.telefon, OLD.telefon, 
        NEW.e_mail, OLD.e_mail, NEW.id_companie, OLD.id_companie, USER(), NOW(), 'UPDATE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);

    
    $cerinta = "Creare trigger insert_imprumut";
    $sql = "CREATE TRIGGER insert_imprumut after INSERT ON imprumut FOR EACH ROW
        begin
        INSERT INTO imprumut_tracking (id_imprumut_tracking, new_id_imprumut, old_id_imprumut, new_data_imprumut, old_data_imprumut, new_durata_imprumut, old_durata_imprumut,
        new_id_cititor, old_id_cititor, new_id_carte, old_id_carte, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_imprumut, NULL, NEW.data_imprumut, NULL, NEW.durata_imprumut,NULL, NEW.id_cititor, NULL, NEW.id_carte, NULL, USER(), NOW(), 'INSERT');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger delete_imprumut";
    $sql = "CREATE TRIGGER delete_imprumut before delete ON imprumut FOR EACH ROW
        begin
        INSERT INTO imprumut_tracking (id_imprumut_tracking, new_id_imprumut, old_id_imprumut, new_data_imprumut, old_data_imprumut, new_durata_imprumut, old_durata_imprumut,
        new_id_cititor, old_id_cititor, new_id_carte, old_id_carte, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NULL, OLD.id_imprumut, NULL, OLD.data_imprumut, NULL, OLD.durata_imprumut, NULL, OLD.id_cititor, NULL, OLD.id_carte, USER(), NOW(),'DELETE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);


    $cerinta = "Creare trigger update_imprumut";
    $sql = "CREATE TRIGGER update_imprumut after update ON imprumut FOR EACH ROW
        begin
        INSERT INTO imprumut_tracking (id_imprumut_tracking, new_id_imprumut, old_id_imprumut, new_data_imprumut, old_data_imprumut, new_durata_imprumut, old_durata_imprumut,
        new_id_cititor, old_id_cititor, new_id_carte, old_id_carte, persoana, change_DATE, operatiune)
        VALUES (DEFAULT, NEW.id_imprumut, OLD.id_imprumut, NEW.data_imprumut, OLD.data_imprumut, NEW.durata_imprumut, OLD.durata_imprumut, NEW.id_cititor, 
        OLD.id_cititor, NEW.id_carte, OLD.id_carte, USER(), NOW(), 'UPDATE');
        END";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
    
    return $output;}
  
  function populare_tabele(){
    $output = '';

    $cerinta = "Populare tabel Autor cu valori.";
    $sql = "INSERT INTO autor (id_autor, nume, prenume, data_nastere, data_deces, descriere) VALUES
    (DEFAULT, 'Blenche','Alec', 1977, NULL, 'Un stil de viata sanatos se bazeaza in primul rand pe iubire si respect. Iubire si respect pentru orice forma de viata care exista pe planeta. Vorbim aici atat de animale si de plante, dar si de oameni. Deci trebuie sa te iubesti si sa te respecti si pe tine. Acesta este crezul lui Alec Blenche.'),
    (DEFAULT, 'Frank', 'Anne', 1929, 1945, 'A fost o fata evreica germana, care si-a pierdut cetatenia germana in exilul olandez si care a cazut victima genocidului nazist din cel de-al Doilea Razboi Mondial. Este cunoscuta datorita jurnalului pe care l-a tinut in ascunzatoarea din Amsterdam, inainte de a fi arestata.'),
    (DEFAULT, 'De Saint-Exupery', 'Antoine', 1900, 1944, 'A fost un aristocrat, romancier, eseist si reporter francez, aviator cazut pe frontul antifascist. S-a facut cunoscut unui cerc larg de cititori in special datorita povestirii Micul Print, una din cele mai raspandite carti din lume, tradusa in trei sute saizeci si una de limbi.'),
    (DEFAULT, 'Schloss', 'Eva', 1929, NULL, 'Memorialista evreica supravietuitoare a Holocaustului si fiica vitrega a lui Otto Frank, tatal lui Margot si Anne Frank.'),
    (DEFAULT, 'Musat', 'Florin', 1965, NULL, 'fara descriere'),
    (DEFAULT, 'Fexeus', 'Henrik', 1971, NULL, 'Este un mentalist, autor si gazda TV suedez. Din 2005 este invitat frecvent, ca expert in limbajul corporal si comunicarea non-verbala, in televiziune si ziare.'),
    (DEFAULT, 'Creanga', 'Ion', 1837, 1889, 'Recunoscut datorita maiestriei basmelor, povestilor si povestirilor sale, Ion Creanga este considerat a fi unul dintre clasicii literaturii romane mai ales datorita operei sale autobiografice Amintiri din copilarie.'),
    (DEFAULT, 'C. Rosenberg', 'Joel', 1967, 2025, 'Joel C. Rosenberg este un strateg de comunicare american / israelian, autor al seriei Ultimul Jihad, fondator al Fondului Joshua si crestin evanghelic.'),
    (DEFAULT, 'Tolstoi', 'Lev', 1828, 1910, 'Tolstoi este unul dintre scriitorii de seama din timpul perioadei cunoscuta ca varsta de aur a literaturii ruse (inceputa in 1820 cu primele opere ale lui Puskin, si terminata in 1880 cu ultimele lucrari ale lui Dostoievski)'),
    (DEFAULT, 'Zusak', 'Markus', 1975, NULL, 'Scriitor australian de origine germana. Este cel mai cunoscut pentru The Thief Book si The Messenger, doua romane care au devenit bestselleruri internationale. A castigat premiul Margaret A. Edwards in 2014.'),
    (DEFAULT, 'Obama', 'Michelle', 1964, NULL, 'A fost prima doamna a Statelor Unite ale Americii intre 2009-2017.'),
    (DEFAULT, 'Bilic',  'Mihaela', 1970, NULL, 'Langa numele Mihaelei Bilic (48 de ani), inca persista eticheta - nutritionistul vedetelor, in ciuda eforturilor sale de a convinge pe toata lumea ca dieta Bilic nu exista si ca slabit egal mancat mai putin si atat.'),
    (DEFAULT, 'Eminescu', 'Mihai', 1850, 1889, 'Poet, prozator si jurnalist roman, socotit de cititorii romani si de critica literara postuma drept cea mai importanta voce poetica din literatura romana. Receptiv la romantismele europene de secol XVIII si XIX, a asimilat viziunile poetice occidentale, creatia sa apartinand unui romantism literar relativ intarziat.'),
    (DEFAULT, 'Djuvara', 'Neagu', 1916, 2018, 'Neagu Bunea Djuvara, cunoscut ca Neagu Djuvara a fost un diplomat, filosof, istoric, jurnalist si romancier roman.'),
    (DEFAULT, 'Tesla', 'Nikola', 1856, 1943, 'Este considerat ca fiind un important om de stiinta al sfarsitului de secol XIX si inceputului de secol XX. Inventiile, precum si munca teoretica ale lui Tesla au pus bazele cunostintelor moderne despre curentul alternativ, puterea electrica, sistemele de curent alternativ,  sistemele de distributie a puterii si motorul pe curent alternativ, care au determinat cea de-a doua Revolutie Industriala.'),
    (DEFAULT, 'Freud', 'Sigmund', 1856, 1939, 'Sigmund Freud a fost un medic neuropsihiatru evreu austriac, fondator al scolii psihologice de psihanaliza. Principalele teorii ale acestei scoli sunt fondate pe urmatoarele ipoteze: Dezvoltarea umana este inteleasa prin schimbarea zonei corporale de gratificare a impulsului sexual.');";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Populare tabel Categorie cu valori.";
    $sql =  "INSERT INTO categorie (id_categorie, tip_categorie) VALUES
    (DEFAULT, 'Fictiune'),
    (DEFAULT, 'Povesti pentru copii'),
    (DEFAULT, 'Basme'),
    (DEFAULT, 'Istorie'),
    (DEFAULT, 'Gastronomie'),
    (DEFAULT, 'Limbi straine'),
    (DEFAULT, 'Psihologie'),
    (DEFAULT, 'Biografii');";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Populare tabel Editura cu valori.";
    $sql = "INSERT INTO editura VALUES
    (DEFAULT, 'Curtea Veche', 'Str. Aurel Vlaicu nr. 35, corp B, sector 2, 020091, Bucuresti'),
    (DEFAULT, 'Litera', 'Calea Floreasca nr. 60, et. 5, sector 1, 014462, Bucuresti'),
    (DEFAULT, 'All', ' Bd. Constructorilor nr. 20A (Cladirea IPROMET, etaj 3), Bucuresti, sector 6'),
    (DEFAULT, 'Polirom', 'Bd. Carol I, nr. 4, Arad'),
    (DEFAULT, 'Lifestyle Publishing', 'Str. Sfantul Constantin nr. 9, ap. 1, sector 1, Bucuresti');";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Populare tabel Carte cu valori.";
    $sql = "INSERT INTO carte VALUES
    (DEFAULT, '9389634101142', 'Hotul de carti', '2011', 4, 1, 10, 4),
    (DEFAULT, '8978796347760', 'Mesagerul', '2015', 27, 1, 10, 1),
    (DEFAULT, '2859996234908', 'Ghid pentru slabit. Sanatatea are gust', '2017', 19, 5, 12, 2),
    (DEFAULT, '9451096347699', 'Am mancat. O fi pacat\'', '2018', 16, 5, 12, 4),
    (DEFAULT, '5163963471245', 'Tocanita pentru suflet', '2016', 14, 5, 12, 5),
    (DEFAULT, '6869634499524', 'Erus si Valea Recunostintei', '2019', 17, 2, 1, 3),
    (DEFAULT, '6556896343412', 'Erus si valea generozitatii', '2018', 8, 2, 1, 5),
    (DEFAULT, '1870963472049', 'Erus si Valea Iubirii', '2018', 21, 2, 1, 3),
    (DEFAULT, '6377963460094', 'Micul print', '2014', 30, 2, 3, 5),
    (DEFAULT, '6527399634229', 'Povestea mea', '2018', 18, 8, 11, 2),
    (DEFAULT, '5579634488944', 'Jurnalul Annei Frank', '2017', 10, 8, 2, 4),
    (DEFAULT, '5783196340008', 'Inventiile mele (Autobiografia)', '2018', 22, 8, 15, 5),
    (DEFAULT, '3167963404837', 'Spovedanie - Cautand sensul vietii (Autobiografia)', '2018', 9, 8, 9, 1),
    (DEFAULT, '8248963410817', 'O scurta istorie ilustrata a romanilor', '2019', 18, 4, 14, 4),
    (DEFAULT, '2907963413225', 'Viata dupa Auschwitz', '2019', 18, 4, 4, 2),
    (DEFAULT, '8384963433955', 'Evadare de la Auschwitz', '2019', 21, 4, 8, 5),
    (DEFAULT, '8062963494313', 'The Third Target: A J. B. Collins Novel', '2015', 14, 4, 8, 2),
    (DEFAULT, '9934963449014', 'Damascus Countdown', '2013', 22, 4, 8, 5),
    (DEFAULT, '9389634101144', 'Anna Karenina', '1995', 23, 1, 9, 4),
    (DEFAULT, '8132896234336', 'Razboi si Pace (adaptare)', '2018', 13, 1, 9, 2),
    (DEFAULT, '9279634381050', 'Basme', '2018', 4, 3, 13, 3),
    (DEFAULT, '2603696347368', 'Calin (file din poveste)', '2014', 7, 2, 13, 4),
    (DEFAULT, '9347796347020', 'Basarabia - pamant romanesc samavolnic rapit', '2013', 23, 4, 13, 5),
    (DEFAULT, '8137963429760', 'Basme si nuvele. Ed. 2016', '2016', 12, 3, 13, 2),
    (DEFAULT, '6029634534529', 'Capra cu 3 iezi', '2019', 3, 2, 7, 2),
    (DEFAULT, '5846429634402', 'Amintiri din copilarie', '2018', 15, 2, 7, 1),
    (DEFAULT, '4625963444566', 'Povestea lui Harap Alb', '2012', 30, 1, 7, 3),
    (DEFAULT, '5196343652494', 'Arta de a citi gandurile', '2014', 25, 7, 6, 5),
    (DEFAULT, '3312963492063', 'Psihologia colectiva si analiza Eului', '2016', 11, 7, 16, 5),
    (DEFAULT, '2013996346243', 'Despre psihanaliza. Ultima scriere a lui Freud', '2019', 23, 7, 16, 4),
    (DEFAULT, '4914859634743', 'Despre vis', '2019', 9, 7, 16, 4),
    (DEFAULT, '5571149634641', 'Gramatica limbii engleze', '2015', 18, 6, 5, 2),
    (DEFAULT, '9405396348866', 'Engleza pentru incepatori - CD inclus', '2014', 18, 6, 5, 5),
    (DEFAULT, '1739634952724', 'Ghid de conversatie roman-englez', '2014', 21, 6, 5, 2);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Populare tabel Companie cu valori.";
    $sql =  "INSERT INTO companie VALUES
    (DEFAULT, 'Avon Romania'),
    (DEFAULT, 'Hertz Belgia'),
    (DEFAULT, 'Avis Italia'),
    (DEFAULT, 'P&G Croatia'),
    (DEFAULT, 'Metro Spania'),
    (DEFAULT, 'Dedeman Romania'),
    (DEFAULT, 'LIDL Germania');";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Populare tabel Cititor cu valori.";
    $sql = "INSERT INTO cititor VALUES
    (DEFAULT, '2651227410930', 'Frumosu', 'Diana Adina','40716562710', 'bester@sbcglobal.net', 7),
    (DEFAULT, '2720323862352', 'Amber', 'Claudia', '40724479502', 'scitext@hotmail.com', 3),
    (DEFAULT, '1720810262946', 'Drusila', 'Gabriel', '40737515811', 'hoangle@icloud.com', 2),
    (DEFAULT, '1730305153431', 'Codreanu', 'Tudor', '40747492411', 'emmanuel@optonline.net', 3),
    (DEFAULT, '2751222413180', 'Melita', 'Magdalena','40754289032', 'henkp@mac.com', 6),
    (DEFAULT, '1760609398990', 'Galeteanu', 'Gabriel', '40766214314', 'aukjan@live.com', 3),
    (DEFAULT, '1790515274500', 'Panoiu', 'Andrei', '40775704059', 'lushe@outlook.com', 7),
    (DEFAULT, '2840903227024', 'Chezia', 'Crina','40789888692', 'denton@optonline.net', 1),
    (DEFAULT, '2850118612099', 'Dascalu', 'Magdalena','40796016990', 'howler@live.com', 4),
    (DEFAULT, '2860813809533', 'Lia', 'Marcela', '40809016359', 'jdhedden@icloud.com', 7),
    (DEFAULT, '2890327851203', 'Hriscu', 'Gabriela', '40745089816', 'andersbr@yahoo.com', 2),
    (DEFAULT, '1890913875718', 'Adascalitei', 'Bogdan', '40786109767', 'grinder@att.net', 3);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Populare tabel Imprumut cu valori.";
    $sql = 'INSERT INTO imprumut VALUES
    (default,"2020-03-25",34,6,31),
    (default,"2020-03-27",41,9,25),
    (default,"2020-03-31",67,8,26),
    (default,"2020-01-13",29,4,33),
    (default,"2020-01-20",74,8,1),
    (default,"2020-01-23",35,9,19),
    (default,"2020-01-27",52,3,27),
    (default,"2020-01-28",28,12,15),
    (default,"2020-02-04",49,1,12),
    (default,"2020-03-10",88,11,31),
    (default,"2020-03-19",70,12,4),
    (default,"2020-03-20",63,4,33),
    (default,"2020-03-03",10,1,31),
    (default,"2020-03-10",74,2,5),
    (default,"2020-03-14",55,6,3),
    (default,"2020-03-23",27,9,4),
    (default,"2020-03-27",73,1,11),
    (default,"2020-01-12",27,12,18),
    (default,"2020-01-15",53,1,15),
    (default,"2020-02-01",86,3,3),
    (default,"2020-02-02",22,2,28),
    (default,"2020-02-08",24,3,24),
    (default,"2020-02-11",42,1,14),
    (default,"2020-02-23",61,6,2),
    (default,"2020-02-25",45,5,22),
    (default,"2020-01-13",64,12,20),
    (default,"2020-01-20",57,7,30),
    (default,"2020-01-23",13,12,30),
    (default,"2020-01-27",73,10,16),
    (default,"2020-01-28",73,7,7),
    (default,"2020-02-04",27,11,22),
    (default,"2020-03-10",33,7,8),
    (default,"2020-03-19",20,5,26),
    (default,"2020-03-20",67,6,33),
    (default,"2020-03-03",56,3,25),
    (default,"2020-03-10",56,12,23),
    (default,"2020-03-14",73,10,13),
    (default,"2020-03-23",62,10,26),
    (default,"2020-03-27",2,7,22),
    (default,"2020-01-12",78,11,4),
    (default,"2020-01-15",87,3,22),
    (default,"2020-02-01",6,5,12),
    (default,"2020-02-08",2,9,6),
    (default,"2020-02-11",32,10,7),
    (default,"2020-02-23",9,7,27),
    (default,"2020-02-25",48,5,8),
    (default,"2020-01-13",80,7,24),
    (default,"2020-01-20",11,6,11),
    (default,"2020-01-23",71,8,17),
    (default,"2020-01-27",56,2,22),
    (default,"2020-01-28",67,6,4),
    (default,"2020-02-04",53,6,4),
    (default,"2020-03-10",74,8,25),
    (default,"2020-02-01",16,4,2),
    (default,"2020-02-02",55,3,1),
    (default,"2020-02-08",7,9,17),
    (default,"2020-02-11",67,11,26),
    (default,"2020-02-23",8,11,5),
    (default,"2020-02-25",14,7,26),
    (default,"2020-01-13",59,6,17),
    (default,"2020-01-20",23,2,22),
    (default,"2020-01-23",51,10,14),
    (default,"2020-01-27",81,7,19),
    (default,"2020-01-28",39,10,8),
    (default,"2020-02-04",48,3,27),
    (default,"2020-03-10",81,5,18),
    (default,"2020-03-19",5,12,23),
    (default,"2020-03-20",75,5,6),
    (default,"2020-03-03",69,3,34),
    (default,"2020-01-20",52,9,33),
    (default,"2020-01-23",71,11,6),
    (default,"2020-01-27",86,10,10),
    (default,"2020-01-28",51,9,16),
    (default,"2020-02-04",58,10,13),
    (default,"2020-03-10",32,10,23),
    (default,"2020-03-19",12,7,23),
    (default,"2020-03-20",66,2,31),
    (default,"2020-03-03",52,5,14),
    (default,"2020-03-10",63,1,32),
    (default,"2020-03-14",74,9,5);';
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    return $output;}

    function restul_cerintelor(){
    $output = '';

    $cerinta = "Am creat tabela TEST pentru a testa pe ea.";
    $sql = "CREATE TABLE test(
    id_test INT,
    legatura_externa INT
    ) ENGINE=InnoDB DEFAULT CHARSET=latin1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
  
    $cerinta = "Adaugare Primary Key pe tabelul creat.";
    $sql = "ALTER TABLE test ADD PRIMARY KEY (id_test);";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
  
    $cerinta = "Schimbarea numelui unei tabele";
    $sql = "RENAME TABLE editura TO tipografie;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Revenirea la numele inițial - instrucțiuni diferite.";
    $sql = "ALTER TABLE tipografie RENAME TO editura;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Adăugați un câmp suplimentar într-o tabelă.";
    $sql = "ALTER TABLE carte ADD coperti_carton INT;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Adăugați un câmp suplimentar într-o tabelă.";
    $sql = "ALTER TABLE carte ADD cod_de_bare INT;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Adăugați un câmp suplimentar într-o tabelă.";
    $sql = "ALTER TABLE companie ADD domeniu_activitate VARCHAR(50);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    $cerinta = "Modificați un câmp al unei tabele (de ex. mărim dimensiunea lui).";
    $sql = "ALTER TABLE carte MODIFY coperti_carton TINYINT;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Adăugați câteva constrângeri pe câteva câmpuri ale unor tabele - să nu permită valori nule.";
    $sql = "ALTER TABLE test MODIFY id_test INT NOT NULL;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Adăugați câteva constrângeri pe câteva câmpuri ale unor tabele - valoare implicită.";
    $sql = 'ALTER TABLE companie change domeniu_activitate cod_caen VARCHAR(50) DEFAULT "fara cod CAEN";';
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Adăugați câteva constrângeri pe câteva câmpuri ale unor tabele - foreign key.";
    $sql = "ALTER TABLE test ADD FOREIGN KEY (legatura_externa) REFERENCES companie (id_companie);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Stergere tabela test.";
    $sql = "DROP TABLE test;"; 
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
    
    $cerinta = "Stergeți un câmp dintr-o tabelă.";
    $sql = "ALTER TABLE carte drop coperti_carton;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    $cerinta = "Stergeți un câmp dintr-o tabelă.";
    $sql = "ALTER TABLE carte drop cod_de_bare;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    $cerinta = "Stergeți un câmp dintr-o tabelă.";
    $sql = "ALTER TABLE companie DROP cod_caen;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Creșteți valoarea de inventar a cărților dintr-o anumită categorie cu 10%.";
    $sql = "UPDATE carte SET numar_carti_disponibile = ROUND(numar_carti_disponibile*1.1,0) WHERE id_categorie = 5;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Schimbați adresa unui cititor.";
    $sql = "UPDATE cititor SET prenume = 'Diana Martina' WHERE id_cititor = 1;/*nu am prevazut tabela CITITOR cu adresa*/";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Modificați anul apariției sau editura unei anumite cărți.";
    $sql = "UPDATE carte SET an_aparitie = '2016', id_editura = 3 WHERE titlu = 'Gramatica limbii engleze'";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Am introdus o carte noua deoarece cartile introduse dupa crearea tabelului sunt deja imprumutate.";
    $sql = "INSERT INTO carte VALUES (DEFAULT, '9389634101145', 'Cartea de proba', '2016', 8, 2, 2, 2);";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
  
    $cerinta = "Implementați 2 instrucțiuni de ștergere de înregistrări din tabelele bazei de DATE - o anumită carte. Comentariul meu: am facut cu subinterogare ca sa fiu sigur ca id_carte e preluat dinamic.";
    $sql =  "DELETE FROM carte WHERE id_carte = (SELECT id_carte FROM carte WHERE titlu = 'Cartea de proba' && ISBN='9389634101145');";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
  
    $cerinta = "Am introdus un cititor noua cititorii introdusi dupa crearea tabelului au deja imprumuturi.";
    $sql = "INSERT INTO cititor (id_cititor,cnp,nume, prenume, telefon, e_mail, id_companie) VALUES (DEFAULT, '2850118612100', 'Costache', 'Miruna', '407960563240', 'miruna@costache.com', 4);";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
  
    $cerinta = "Afisare cititori care nu au imprumutat vreo carte.";
    $sql = "SELECT * FROM cititor WHERE id_cititor NOT in(SELECT id_cititor FROM imprumut);";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
  
    $cerinta = "Afisare carti care nu au fost imprumutate.";
    $sql = "SELECT * FROM carte WHERE id_carte NOT in(SELECT id_carte FROM imprumut);";
    $output .= rulare_si_afisare_query($cerinta,$sql,false);
  
    $cerinta = "Implementați 2 instrucțiuni de ștergere de înregistrări din tabelele bazei de DATE - un cititor dintr-o anumită localitate. Comentariul meu: am facut cu subinterogare ca sa fiu sigur ca id_cititor e preluat dinamic.";
    $sql =  "DELETE FROM cititor where id_cititor = (SELECT id_cititor FROM cititor WHERE e_mail ='miruna@costache.com');";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări simple - afișarea cărților dintr-o anumită categorie.";
    $sql = "SELECT titlu FROM carte where id_categorie = 7;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări simple - afișarea cititorilor dintr-o anumită localitate. Comentariul meu: am folosit e-mail in loc de localitate.";
    $sql = "SELECT CONCAT_WS(' ',nume,prenume) AS nume_cititor FROM cititor WHERE e_mail LIKE '%live.com';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări simple - afișarea cărților unui autor.";
    $sql = "SELECT titlu FROM carte WHERE id_autor = 16;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări simple - afișarea împrumuturilor dintr-un anumit interval de timp.";
    $sql = "SELECT * FROM imprumut WHERE data_imprumut BETWEEN '2020-01-1' AND '2020-01-21';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări simple - cărțile apărute într-un interval de timp.";
    $sql = "SELECT titlu FROM carte WHERE an_aparitie BETWEEN 2015 AND 2017;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări simple - numărul de împrumuturi din luna curentă.";
    $sql = "SELECT COUNT(id_imprumut) FROM imprumut WHERE MONTH(data_imprumut) = month(NOW());";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări utilizând operatori și funcții MySQL - alipiți anumite cîmpuri de tip șir de caractere.";
    $sql = "SELECT CONCAT_WS(' ',nume,prenume) AS nume_cititor FROM cititor;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări utilizând operatori și funcții MySQL - alipiți anumite cîmpuri de tip șir de caractere.";
    $sql = "SELECT CONCAT(nume,' ',prenume) AS nume_cititor FROM cititor;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări utilizând operatori și funcții MySQL - afișați numărul de cititori din București. Comentariul meu: am folosit e-mail in loc de localitate.";
    $sql = "SELECT COUNT(id_cititor) FROM cititor where e_mail LIKE '%live.com';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interogări utilizând operatori și funcții MySQL - cartea (cărțile) cu cea mai mare respectiv cea mai mică valoare de inventar.";
    $sql = "SELECT titlu, MAX(numar_carti_disponibile) as maxim FROM carte GROUP BY titlu ORDER BY maxim DESC LIMIT 1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    $cerinta = "Implementați 5 interogări utilizând operatori și funcții MySQL - cartea (cărțile) cu cea mai mare respectiv cea mai mică valoare de inventar.";
    $sql = "SELECT titlu, MIN(numar_carti_disponibile) as minim FROM carte GROUP BY titlu ORDER BY minim LIMIT 1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
    
    $cerinta = "Implementați 5 interorgări complexe pe tabelele bazei de date utilizând join-uri și reuniuni - numele cititorilor și adresa precum și cărțile împrumutate acestora într-un interval de timp, numele categoriei și cărțile din această categorie. Comentariul meu: am folosit si varianta de unire a tabelelor cu sintaxa ON";
    $sql = "SELECT a.nume, a.prenume, a.e_mail, c.titlu, d.tip_categorie FROM cititor a 
    JOIN imprumut b 
    ON (a.id_cititor=b.id_cititor) 
    JOIN carte c 
    USING (id_carte) 
    JOIN categorie d 
    USING (id_categorie)
    WHERE b.data_imprumut BETWEEN '2020-01-1' AND '2020-01-21';/*nu m-am priceput sa implementez si cerinta: cărțile din această categorie*/";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interorgări complexe pe tabelele bazei de date utilizând join-uri și reuniuni - cititorii care au împrumutat o anumită carte.";
    $sql = "SELECT a.nume, a.prenume, c.titlu FROM cititor a 
    JOIN imprumut b 
    USING (id_cititor) 
    JOIN carte c 
    USING (id_carte) 
    WHERE c.titlu = 'Capra cu 3 iezi';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interorgări complexe pe tabelele bazei de date utilizând join-uri și reuniuni - autorii care au publicat la o anumită editură.";
    $sql = "SELECT distinct concat(a.nume,' ',a.prenume) AS nume_autor, nume_editura 
    FROM autor a 
    JOIN carte b 
    USING (id_autor) 
    JOIN editura c 
    USING (id_editura) 
    WHERE c.nume_editura = 'All';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interorgări complexe pe tabelele bazei de date utilizând join-uri și reuniuni - numărul de cărți din fiecare categorie.";
    $sql = "SELECT COUNT(id_carte), tip_categorie 
    FROM carte a 
    JOIN categorie b 
    USING (id_categorie) 
    GROUP BY tip_categorie;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interorgări complexe pe tabelele bazei de date utilizând join-uri și reuniuni - cărțile apărute într-un anumit an, editura la care au apărut și numele autorului.";
    $sql = "SELECT a.titlu, CONCAT_WS(' ',b.nume,b.prenume) AS nume_autor, c.nume_editura 
    FROM carte a 
    JOIN autor b 
    USING (id_autor)
    JOIN editura c 
    USING (id_editura) 
    WHERE an_aparitie = 2018;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 5 interorgări complexe pe tabelele bazei de date utilizând join-uri și reuniuni - cititorii și editurile dintr-o anumită localitate.";
    $sql = "SELECT CONCAT_WS(' ',nume,prenume) AS nume_cititor FROM cititor WHERE e_mail LIKE '%optonline.net'
    UNION ALL
    SELECT nume_editura FROM editura WHERE adresa LIKE '%arad%';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 3 subinterogări pe baza tabelelelor din baza de date - cartea cu cea mai mare valoare de inventar împrumutată în luna curentă.";
    $sql = "SELECT titlu, numar_carti_disponibile FROM carte WHERE id_carte IN (SELECT id_carte FROM imprumut WHERE MONTH(data_imprumut) = MONTH(NOW())) order by numar_carti_disponibile DESC LIMIT 1;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 3 subinterogări pe baza tabelelelor din baza de date - autorii cărților împrumutate într-un anumit an. Comentariul meu: am folosit luna, pentru ca anul era acelasi peste tot.";
    $sql = "SELECT CONCAT_WS(' ',nume,prenume) AS nume_autor FROM autor WHERE id_autor IN 
    (SELECT distinct id_autor FROM carte WHERE id_carte IN 
    (SELECT id_carte FROM imprumut WHERE month(data_imprumut) = 01));";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);
  
    $cerinta = "Implementați 3 subinterogări pe baza tabelelelor din baza de date - cărțile împrumutate în ordinea descrecătoare a valorii lor de inventar sau a datei de împrumut.";
    $sql = "SELECT titlu, numar_carti_disponibile FROM carte WHERE id_carte IN (SELECT DISTINCT id_carte FROM imprumut) ORDER BY numar_carti_disponibile desc;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Implementati 3 tabele virtuale pe baza anumitor selectii - view cu ultimii 5 cititori înregistrati care au împrumutat carti. Comentariul meu: Am vrut sa creez VIEW-ul IN baza a doua subinterogari (CREATE view ultimii_5_cititori_inregistrati AS ( SELECT * FROM imprumut WHERE id_cititor IN (SELECT id_cititor FROM cititor order by id_cititor desc LIMIT 5));), insa am primit eroarea 'SQL Error (1235): This version of MariaDB doesnt yet support LIMIT & IN/ALL/ANY/SOME subquery. Apoi am vrut sa creez un tabel temporar in care sa-mi stochez id-urile ultimilor 5 cititori inregistrati, insa nu ma lasa sa creez dupa view-ul in baza lui, asa ca am creat un tabel normal";
    $sql = "CREATE table temp1 AS (SELECT id_cititor FROM cititor order by id_cititor desc LIMIT 5);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Am creat VIEW-ul in baza tabelului temp1 creat mai sus";
    $sql = "CREATE VIEW imprumuturi_ultimii_5_utilizatori AS (
        SELECT a.titlu, b.data_imprumut, b.id_cititor FROM carte a
        JOIN imprumut b
        USING (id_carte)
        WHERE b.id_cititor IN (SELECT * FROM temp1));";
    $output .= rulare_si_afisare_query($cerinta,$sql,false); 

    $cerinta = "Afisati datele din view";
    $sql = "SELECT * FROM imprumuturi_ultimii_5_utilizatori;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 


    $cerinta = "Implementati 3 tabele virtuale pe baza anumitor selectii - view cu citorii care au împrumutat carti într-un anumit interval de timp. Comentariul meu: imprumuturile din a doua jumatate a lunii Ianuarie";
    $sql = "CREATE VIEW imprumuturi_in_interval_de_timp AS (
        SELECT * FROM imprumut WHERE data_imprumut BETWEEN '2020-01-15' AND '2020-01-31');
        ";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Afisati datele din view";
    $sql = "SELECT * FROM imprumuturi_in_interval_de_timp ;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Implementati 3 tabele virtuale pe baza anumitor selectii - view cu toate împrumuturile din luna curenta. Comentariul meu: am folosit luna precedenta ";
    $sql = "CREATE VIEW imprumuturi_luna_precedenta AS (
        SELECT * FROM imprumut WHERE month(data_imprumut) = (MONTH(NOW())-1));";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Afisati datele din view";
    $sql = "SELECT * FROM imprumuturi_luna_precedenta;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Comentariul meu: creare view_autor pentru probe inserare";
    $sql = "create view view_autor AS (SELECT * FROM autor);";
    $output .= rulare_si_afisare_query($cerinta,$sql,false); 

    $cerinta = "Inserati date într-un view. Comentariul meu: am folosit o alta varianta a sintaxei INSERT";
    $sql = "INSERT INTO view_autor (id_autor, nume, prenume, data_nastere, data_deces, descriere) VALUES(DEFAULT,'Robert','Paul',1961,NULL,'Paul Roberts este un jurnalist american si autor al doua carti de non-fictiune, The End of Oil si The End of Food.'), (DEFAULT,'Arghezi','Tudor',1880,1967,'(pseudonimul lui Ion Nae Theodorescu) a fost un scriitor roman, cunoscut pentru contributia sa la dezvoltarea liricii romanesti sub influenta baudelairianismului. Opera sa poetica, de o originalitate exemplara, reprezinta o alta varsta marcanta a literaturii romane.');";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Afisati  datele din view.";
    $sql = "SELECT * FROM view_autor;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Modificati date într-o tabela pe baza careia ati implementat un view.";
    $sql = "DELETE FROM autor WHERE nume='Robert' AND prenume='Paul';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Stergeti date într-o tabela pe baza careia ati implementat un view.";
    $sql = "UPDATE autor set nume='Ion', prenume='Nae Theodorescu' WHERE nume='Arghezi' AND prenume='Tudor';";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Afisati  datele din view.";
    $sql = "SELECT * FROM view_autor;";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Creati 2 indecsi simpli, pe coloane care se preteaza la indexare din tabelele bazei de date.";
    $sql = "CREATE INDEX index_nume ON autor (nume ASC);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Verificare index";
    $sql = "SHOW INDEX FROM autor;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false); 
    
    $cerinta = "Creati 2 indecsi simpli, pe coloane care se preteaza la indexare din tabelele bazei de date.";
    $sql = "CREATE INDEX index_titlu ON carte (titlu ASC);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true); 

    $cerinta = "Creati un index de unicitate, pe coloane care se preteaza la indexare din tabelele bazei de date.";
    $sql = "CREATE unique INDEX index_isbn ON carte (ISBN ASC);";
    $output .= rulare_si_afisare_query($cerinta,$sql,true);     

    $cerinta = "Verificare index.";
    $sql = "SHOW INDEX FROM carte;";
    $output .= rulare_si_afisare_query($cerinta,$sql,false); 

    return $output;
}
  