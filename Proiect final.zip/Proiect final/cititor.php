<?php
$output  = "";
require_once "functions.php";
if (conectare("Operatiuni cititor")){
  $output .= "<h3>1. Cititori</h3>";
  $output .= afisare_tabel_cititor();
  $output .= "<h3>2. introducere cititor nou</h3>";
  $output .= "<form method='get'>
  <table border=1>
    <tr>
      <th>ID CITITOR</th>
      <th>CNP</th>
      <th>NUME</th>
      <th>PRENUME</th>
      <th>TELEFON</th>
      <th>E-MAIL</th>
      <th>COMPANIE</th>
    </tr>
    <tr>
      <td>default</td>
      <td><input type='text' name='cnp' required='true'></td>
      <td><input type='text' name='nume' required='true'></td>
      <td><input type='text' name='prenume' required='true'></td>
      <td><input type='text' name='telefon'></td>
      <td><input type='text' name='e_mail'></td>";
      
    $sql = 'SELECT id_companie, nume_companie FROM COMPANIE';
    echo_sql($sql,false);
    if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
        $output .= "<td><select name='id_companie'><option value='neales'>".' '."</option>";
          while($row = mysqli_fetch_array($result)){
            $output .=  "<option value=".$row['id_companie'].">".$row['nume_companie']."</option>";
          }
          $output .=  "</select></td>";
          mysqli_free_result($result);// Free result set
      }} 
      $output .= "</tr></table><center><input type='submit' value='Introdu cititorul in baza de date'></center></form><br><br>";
        
    if (!empty($_REQUEST)){
      $text_popup = "";
      $erori = 0;
      $sql = '';
      $cnp = $_REQUEST['cnp'];
      $nume = $_REQUEST['nume'];
      $prenume = $_REQUEST['prenume'];
      $telefon = $_REQUEST['telefon'];
      $e_mail = $_REQUEST['e_mail'];
      $id_companie = $_REQUEST['id_companie'];

      $sql = "SELECT cnp FROM cititor;";
      echo_sql($sql,false);
      if($result = mysqli_query($link, $sql)){
        if(mysqli_num_rows($result) > 0){
          while($row = mysqli_fetch_array($result)){
            if ($row['cnp'] == $cnp){
              $text_popup .= '- CNP-ul exista deja in baza de date;\n';
              $erori++;
            }
          }
        }
        mysqli_free_result($result);// Free result set
        } 


      if (strlen($cnp)<> 13 or !is_numeric($cnp)){
        $text_popup .= '- CNP-ul trebuie sa fie de 13 cifre;\n';
        $erori++;
      }

      if (strlen($nume)> 45){
        $text_popup .= '- numele cititorului depaseste 45 caractere;\n';
        $erori++;
      }

      if (strlen($prenume)> 45){
        $text_popup .= '- prenume cititorului depaseste 45 caractere;\n';
        $erori++;
      }

      if (strlen($telefon)> 15){
        $text_popup .= '- telefonul depaseste 15 caractere;\n';
        $erori++;
      }

      if (!is_numeric($telefon)){
        $text_popup .= '- telefonul trebuie sa fie numeric;\n';
        $erori++;
      }

      if(strlen($e_mail) > 40){
        $text_popup .= '- e-mailul depaseste 40 caractere;\n';
        $erori++;
      }

      if ($id_companie == 'neales'){
        $text_popup .= '- nu ai ales compania;\n';
        $erori++;
      }

      if ($erori != 0){
        $text_popup = 'Cititorul nu a putut fi introdus in baza de date deoarece:\n'.$text_popup;
      } else {
        $sql = "INSERT INTO cititor VALUES (default,'{$cnp}','{$nume}','{$prenume}','{$telefon}','{$e_mail}',{$id_companie});";
        echo_sql($sql,false);
        if($result = mysqli_query($link, $sql)){
          if($result){
            $text_popup .= 'Cititorul '.strtoupper($nume.' '.$prenume).' a fost introdus cu succes in baza de date';
          }} 
      }
      $output .= popup($text_popup);
    }
    $output .= "</body></html>";
    deconectare();
}
echo $output;