<?php
$output  = "";
require_once "functions.php";
if (conectare("Operatiuni editura")){
  $output .= "<h3>1. Edituri partenere</h3>";
  $output .= afisare_tabel_editura();
  $output .= "<h3>2. introducere editura noua</h3>";
  $output .= "<form method='get'>
  <table border=1>
    <tr>
      <th>ID EDITURA</th>
      <th>NUME EDITURA</th>
      <th>ADRESA</th>
    </tr>
    <tr>
      <td>default</td>
      <td><input type='text' name='nume_editura' required='true'></td>
      <td><input type='text' name='adresa'></td>
    </tr>
  </table><center><input type='submit' value='Introdu editura in baza de date'></center></form><br><br>";
    
    if (!empty($_REQUEST)){
      $text_popup = "";
      $erori = 0;
      $sql = '';
      $nume_editura = $_REQUEST['nume_editura'];
      $adresa = $_REQUEST['adresa'];

      if (strlen($nume_editura)> 45){
        $text_popup .= '- numele editurii depaseste 45 caractere;\n';
        $erori++;
      }

      if (strlen($adresa)> 100){
        $text_popup .= '- adresa editurii depaseste 100 caractere;\n';
        $erori++;
      }

      if ($erori != 0){
        $text_popup = 'Editura nu a putut fi introdusa in baza de date deoarece:\n'.$text_popup;
      } else {
        $sql = "INSERT INTO editura VALUES (default,'{$nume_editura}','{$adresa}');";
        echo_sql($sql,false);
        if($result = mysqli_query($link, $sql)){
          if($result){
            $text_popup .= 'Editura '.strtoupper($nume_editura).' a fost introdusa cu succes in baza de date';
          }} 
      }
      $output .= popup($text_popup);
    }
    $output .= "</body></html>";
    deconectare();
}
echo $output;