<?php
$output  = "";
require_once "functions.php";
if (conectare("Operatiuni companie")){
  $output .= "<h3>1. Companii</h3>";
  $output .= afisare_tabel_companie();
  $output .= "<h3>2. introducere companie noua</h3>";
  $output .= "<form method='get'>
  <table border=1>
    <tr>
      <th>ID COMPANIE</th>
      <th>NUME COMPANIE</th>
    </tr>
    <tr>
      <td>default</td>
      <td><input type='text' name='nume_companie' required='true'></td>
    </tr>
  </table><center><input type='submit' value='Introdu companie in baza de date'></center></form><br><br>";

    if (!empty($_REQUEST)){
      $text_popup = "";
      $erori = 0;
      $sql = '';
      $nume_companie = $_REQUEST['nume_companie'];

      if (strlen($nume_companie)> 30){
        $text_popup .= '- numele companiei depaseste 30 caractere;\n';
        $erori++;
      }

      if ($erori != 0){
        $text_popup = 'Compania nu a putut fi introdusa in baza de date deoarece:\n'.$text_popup;
      } else {
        $sql = "INSERT INTO companie VALUES (default,'{$nume_companie}');";
        echo_sql($sql,false);
        if($result = mysqli_query($link, $sql)){
          if($result){
            $text_popup .= 'Compania '.strtoupper($nume_companie).' a fost introdusa cu succes in baza de date';
          }} 
      }
      $output .= popup($text_popup);
    }
    $output .= "</body></html>";
    deconectare();
  }
  echo $output;