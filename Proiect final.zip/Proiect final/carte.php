<?php
$output  = "";
require_once "functions.php";
if (conectare("Operatiuni carte")){
  $output .= "<h3>1. Carti aflate in biblioteca</h3>";
  $output .= afisare_tabel_carte();
  $output .= "<h3>2. introducere carte noua in biblioteca</h3>";
  $output .= "<form method='get'><table border=1>
    <tr>
      <th>CARTE</th>
      <th>ISBN</th>
      <th>TITLU</th>
      <th>AN APARITIE</th>
      <th>NUMAR CARTI DISPONIBILE</th>
      <th>CATEGORIE</th>
      <th>AUTOR</th>
      <th>EDITURA</th>                  
  </tr>
  <tr>
    <td>default</td>
    <td><input type='text' name='ISBN' required='true'></td>
    <td><input type='text' name='titlu' required='true'></td>
    <td><input type='text' name='an_aparitie' required='true'></td>
    <td><input type='text' name='numar_carti_disponibile' required='true'></td>
    ";

    $sql = 'SELECT id_categorie, tip_categorie FROM CATEGORIE';
    echo_sql($sql,false);
    if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
        $output .= "<td><select name='id_categorie'><option value='neales'>".' '."</option>";
          while($row = mysqli_fetch_array($result)){
            $output .=  "<option value=".$row['id_categorie'].">".$row['tip_categorie']."</option>";
          }
          $output .=  "</select></td>";
          mysqli_free_result($result);// Free result set
      }} 

      $sql = 'SELECT id_autor, concat_ws(" ",nume, prenume) as nume_concatenat FROM AUTOR';
      echo_sql($sql,false);
      if($result = mysqli_query($link, $sql)){
        if(mysqli_num_rows($result) > 0){
          $output .= "<td><select name='id_autor'><option value='neales'>".' '."</option>";
            while($row = mysqli_fetch_array($result)){
              $output .=  "<option value=".$row['id_autor'].">".$row['nume_concatenat']."</option>";
            }
            $output .=  "</select></td>";
            mysqli_free_result($result);// Free result set
        }} 

    $sql = 'SELECT id_editura, nume_editura FROM EDITURA';
    echo_sql($sql,false);
    if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
        $output .= "<td><select name='id_editura'><option value='neales'>".' '."</option>";
          while($row = mysqli_fetch_array($result)){
            $output .=  "<option value=".$row['id_editura'].">".$row['nume_editura']."</option>";
          }
          $output .=  "</select></td>";
          mysqli_free_result($result);// Free result set
      }} 


    $output .="</tr></table><center><input type='submit' value='Introdu carte in baza de date'></center></form><br><br>";


    if (!empty($_REQUEST)){
      $text_popup = "";
      $erori = 0;
      $sql = '';
      $ISBN = $_REQUEST['ISBN'];
      $titlu = $_REQUEST['titlu'];
      $an_aparitie = $_REQUEST['an_aparitie'];
      $numar_carti_disponibile = $_REQUEST['numar_carti_disponibile'];
      $id_categorie = $_REQUEST['id_categorie'];
      $id_editura = $_REQUEST['id_editura'];
      $id_autor = $_REQUEST['id_autor'];
      if (strlen($ISBN) <> 13){
        $text_popup .= '- lungimea ISBN-ului nu este de 13 caractere;\n';
        $erori++;
      }
      if (strlen($titlu)> 60){
        $text_popup .= '- lungimea titlului depaseste 60 caractere;\n';
        $erori++;
      }
      if (strlen($an_aparitie) <> 4 or !is_numeric($an_aparitie)){
        $text_popup .= '- anul trebuie sa fie din 4 cifre;\n';
        $erori++;
      }
    
      if (!is_numeric($numar_carti_disponibile)){
        $text_popup .= '- numarul de carti disponibile trebuie sa fie compus din cifre;\n';
        $erori++;
      }

      if ($id_categorie == 'neales'){
        $text_popup .= '- nu ai ales categoria;\n';
        $erori++;      
      }

      if ($id_editura == 'neales'){
        $text_popup .= '- nu ai ales editura;\n';
        $erori++;      
      }
      
      if ($id_autor == 'neales'){
        $text_popup .= '- nu ai ales autorul;\n';
        $erori++;      
      }

      if ($erori != 0){
        $text_popup = 'Cartea nu a putut fi introdusa in baza de date deoarece:\n'.$text_popup;
      } else {
        $sql = "INSERT INTO carte VALUES (default,'{$ISBN}','{$titlu}','{$an_aparitie}',{$numar_carti_disponibile},{$id_categorie},{$id_autor},{$id_editura});";
        echo_sql($sql,false);
        if($result = mysqli_query($link, $sql)){
          if($result){
            $text_popup .= 'Cartea '.strtoupper($titlu).' a fost introdusa cu succes in baza de date';
          }} 
      }
      $output .= popup($text_popup);
    }
    $output .= "</body></html>";
    deconectare();
}
echo $output;