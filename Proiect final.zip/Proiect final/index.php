<?php  
require_once "functions.php";
if (conectare("PROIECT MySQL")){
    $output = '<a id=carte href="carte.php" target="_blank">Vizualizeaza tabel carte / Introducere carte noua</a><br>
    <a href="categorie.php"  target="_blank">Vizualizeaza tabel categorie / Introducere categorie noua</a><br>
    <a href="autor.php" target="_blank">Vizualizeaza tabel autor / Introducere autor nou</a><br>
    <a href="editura.php" target="_blank">Vizualizeaza tabel editura / Introducere editura noua</a><br>
    <a href="cititor.php" target="_blank">Vizualizeaza tabel cititor / Introducere cititor nou</a><br>
    <a href="imprumut.php" target="_blank">Vizualizeaza tabel imprumut / Introducere imprumut nou</a><br>
    <a href="companie.php" target="_blank">Vizualizeaza tabel companie / Introducere companie noua</a><br>
    <a href="relatii_tabele.JPG" target="_blank">Vezi diagrama bazei de date</a><br>
        <p><h3>EVIDENTA CARTILOR DINTR-O BIBLIOTECA</h3></P>
    <P>
    Proiectați o bază de date care să gestioneze evidența cărților dintr-o bibliotecă. Proiectați tabelele care să definească următoarele entități: <br>
    <ul>
        <li>CARTE</li><br>
        <li>CATEGORIE</li><br>
        <li>AUTOR</li><br>
        <li>EDITURĂ</li><br>
        <li>CITITOR</li><br>
        <li>ÎMPRUMUT</li><br>
    </ul>
    </P>
    De asemenea, proiectați relațiile între tabele și stabiliți atributele fiecărei entități în parte, precum și opționalitatea fiecărui atribut (cheie primară, obligatoriu, opțional). Puteți implementa tabele și pentru alte entități în afara celor enumerate, dacă le considerați necesare.</p>

    <h3>CERINTE:</h3>
    <ol>
    <li>Creați baza de date și tabelele proiectate anterior prin scrierea instrucțiunilor corespunzătoare, utilizând un client MySQL (HeidiSQL, MySQL Workbench, etc.).<br>
    Realizați 5 operații de modificare a structurii tabelelor după ce acestea au fost create (schimbarea numelui unei tabele, revenirea la numele inițial - instrucțiuni diferite, adăugați un câmp suplimentar într-o tabelă, ștergeți un câmp dintr-o tabelă, modificați un câmp al unei tabele (de ex. mărim dimensiunea lui), adăugați câteva constrângeri pe câteva câmpuri ale unor tabele (de ex. valoare implicită, să nu permită valori nule, foreign key, etc.).</li><br>

    <li>Introduceți date în toate tabele bazei de date utilizând instrucțiuni ale LMD.</li><br>

    <li>Tabela de cărți să conțină minim 30 de înregistrări, tabelele de cititori, împrumuturi și autori minim 10 înregistrări.</li><br>';
    
    $output .= creare_db();
    $output .= creare_tabele();
    $output .= creare_tabele_tracking();
    $output .= creare_triggere();
    $output .= populare_tabele();

    $output .= '<li>Realizați 2 instrucțiuni de modificare (update) a anumitor înregistrări pe două tabele diferite (de exemplu, creșteți valoarea de inventar a cărților dintr-o anumită categorie cu 10%, schimbați adresa unui cititor, modificați anul apariției sau editura unei anumite cărți.</li><br>

    <li>Implementați 2 instrucțiuni de ștergere de înregistrări din tabelele bazei de date (de exemplu o anumită carte, un cititor dintr-o anumită localitate, un împrumut dintr-o anumită dată, etc.).</li><br>

    <li>Implementați 5 interogări simple pe tabelele bazei de date (de exemplu: afișarea cărților dintr-o anumită categorie, afișarea cititorilor dintr-o anumită localitate, afișarea cărților unui auto, afișarea împrumuturilor dintr-un anumit interval de timp, cărțile apărute într-un interval de timp, numărul de împrumuturi din luna curentă, etc.).</li><br>

    <li>Implementați 5 interogări utilizând operatori și funcții MySQL (de ex: alipiți anumite cîmpuri de tip șir de caractere, afișați numărul de cititori din București, afișați împrumuturile dintr-o anumită lună sau dintr-un anumit an, cartea (cărțile) cu cea mai mare, respectiv cea mai mică valoare de inventar, etc.).</li><br>

    <li>Implementați 5 interorgări complexe pe tabelele bazei de date utilizând join-uri și reuniuni (de exemplu: numele cititorilor și adresa precum și cărțile împrumutate acestora într-un interval de timp, numele categoriei și cărțile din această categorie, cititorii care au împrumutat o anumită carte, autorii care au pulicat la o anumită editură, numărul de cărți din fiecare categorie, cărțile apărute într-un anumit an, editura la care au apărut și numele autorului, cititorii și editurile dintr-o anumită localitate, etc.).</li><br>

    <li>Implementați 3 subinterogări pe baza tabelelelor din baza de date (de exemplu: cartea cu cea mai mare valoare de inventar împrumutată în luna curentă, autorii cărților împrumutate într-un anumit an, cărțile împrumutate în ordinea descrecătoare a valorii lor de inventar sau a datei de împrumut, etc.).</li><br>

    <li>Implementați 3 tabele virtuale pe baza anumitor selecții (fie interogări realizate anterior, fie altele noi, cum ar fi view cu toți cititorii din București, view cu toate împrumuturile din luna curentă, view cu ultimii 5 cititori înregistrați care au împrumutat cărți, view cu citorii care au împrumutat cărți într-un anumit interval de timp, etc.). Afișați datele din view.</li><br>

    <li>Inserați date într-un view. Modificați și ștergeți date într-o tabelă pe baza căreia ați implementat un view. Afișați datele din view.</li><br>

    <li>Creați 2 indecși simpli și unul de unicitate, pe coloane care se pretează la indexare din tabelele bazei de date. </li><br>';
    $output .= restul_cerintelor();
    $output .= '
    </ol>
    </body>
    </HTML>';

echo $output;}