<?php
$output  = "";
require_once "functions.php";
if (conectare("Operatiuni categorie")){
  $output .= "<h3>1. Categorii de carti aflate in biblioteca</h3>";
  $output .= afisare_tabel_categorie();
  $output .= "<h3>2. introducere categorie noua</h3>";
  $output .= "<form method='get'>
  <table border=1>
    <tr>
      <th>ID CATEGORIE</th>
      <th>TIP CATEGORIE</th>
    </tr>
    <tr>
      <td>default</td>
      <td><input type='text' name='tip_categorie' required='true'></td>
    </tr>
  </table><center><input type='submit' value='Introdu categorie in baza de date'></center></form><br><br>";

    if (!empty($_REQUEST)){
      $text_popup = "";
      $erori = 0;
      $sql = '';
      $tip_categorie = $_REQUEST['tip_categorie'];

      if (strlen($tip_categorie)> 30){
        $text_popup .= '- numele companiei depaseste 30 caractere;\n';
        $erori++;
      }

      if ($erori != 0){
        $text_popup = 'Categoria nu a putut fi introdusa in baza de date deoarece:\n'.$text_popup;
      } else {
        $sql = "INSERT INTO categorie VALUES (default,'{$tip_categorie}');";
        echo_sql($sql,false);
        if($result = mysqli_query($link, $sql)){
          if($result){
            $text_popup .= 'Categoria '.strtoupper($tip_categorie).' a fost introdusa cu succes in baza de date';
          }} 
      }
      $output .= popup($text_popup);
    }
    $output .= "</body></html>";
    deconectare();
}
echo $output;