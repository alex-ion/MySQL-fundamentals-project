<?php
$output  = "";
require_once "functions.php";
if (conectare("Operatiuni autor")){
  $output .= "<h3>1. Autori</h3>";
  $output .= afisare_tabel_autor();
  $output .= "<h3>2. introducere autor nou</h3>";
  $output .= "<form method='get'>
  <table border=1>
    <tr>
      <th>ID AUTOR</th>
      <th>NUME</th>
      <th>PRENUME</th>
      <th>DATA NASTERE</th>
      <th>DATA DECES</th>
      <th>DESCRIERE</th>
    </tr>
    <tr>
      <td>default</td>
      <td><input type='text' name='nume' required='true'></td>
      <td><input type='text' name='prenume' required='true'></td>
      <td><input type='text' name='data_nastere' required='true'></td>
      <td><input type='text' name='data_deces'></td>
      <td><input type='text' name='descriere'></td>
    </tr>
  </table><center><input type='submit' value='Introdu autorul in baza de date'></center></form><br><br>";

    if (!empty($_REQUEST)){
      $text_popup = "";
      $erori = 0;
      $sql = '';
      $nume = $_REQUEST['nume'];
      $prenume = $_REQUEST['prenume'];
      $data_nastere = $_REQUEST['data_nastere'];
      $data_deces = $_REQUEST['data_deces'];
      $descriere = $_REQUEST['descriere'];

      if (strlen($nume)> 45){
        $text_popup .= '- numele autorului depaseste 45 caractere;\n';
        $erori++;
      }

      if (strlen($prenume)> 45){
        $text_popup .= '- prenume autorului depaseste 45 caractere;\n';
        $erori++;
      }

      if(strlen($data_nastere) <> 4 or !is_numeric($data_nastere)){
        $text_popup .= '- anul de nastere trebuie sa fie din 4 cifre;\n';
        $erori++;
      }

      if(strlen($data_deces) === 0){
        $data_deces = 'default';
      } elseif (strlen($data_deces) <> 4 or !is_numeric($data_deces)){
        $text_popup .= '- anul decesului trebuie sa fie din 4 cifre;\n';
        $erori++;
      }

      if (strlen($descriere)> 400){
        $text_popup .= '- descrierea depaseste 400 caractere;\n';
        $erori++;
      }

      if(strlen($descriere) === 0){
        $descriere = 'default';
      } else {
        $descriere = "'{$descriere}'";
      }

      if ($erori != 0){
        $text_popup = 'Autorul nu a putut fi introdus in baza de date deoarece:\n'.$text_popup;
      } else {
        $sql = "INSERT INTO autor VALUES (default,'{$nume}','{$prenume}',{$data_nastere},{$data_deces},{$descriere});";
        echo_sql($sql,false);
        if($result = mysqli_query($link, $sql)){
          if($result){
            $text_popup .= 'Autorul '.strtoupper($nume.' '.$prenume).' a fost introdus cu succes in baza de date';
          }} 
      }
      $output .= popup($text_popup);
    }
    $output .= "</body></html>";
    deconectare();
  }

  echo $output;