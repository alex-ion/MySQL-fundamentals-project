<?php
$output  = "";
require_once "functions.php";
if (conectare("Operatiuni imprumut")){
  $output .= "<h3>1. Imprumuturi</h3>";
  $output .= "Legenda:<br><font color=red>&#9830 - imprumuturile marcate cu rosu au intarzieri de peste 30 de zile</font>
  <br><font color=green>&#9830 - imprumuturile marcate cu verde nu prezinta intarzieri</font><br>";
  $output .= afisare_tabel_imprumut();
  $output .= "<h3>2. introducere imprumut nou</h3>";
  $output .= "<form method='get'>
  <table border=1>
    <tr>
      <th>ID IMPRUMUT</th>
      <th>DATA IMPRUMUT</th>
      <th>DURATA IMPRUMUT INITIAL (zile)</th>
      <th>NUME CITITOR</th>
      <th>CARTE</th>               
  </tr>
  <tr>
    <td>default</td>
    <td><input type='text' name='data_imprumut' required='true' placeholder='AAAA-LL-ZZ'></td>
    <td><input type='text' name='durata_imprumut' required='true'></td>
    ";

    $sql = 'SELECT id_cititor, concat_ws(" ",nume, prenume) as nume_concatenat FROM CITITOR;';
    echo_sql($sql,false);
    if($result = mysqli_query($link, $sql)){
      if(mysqli_num_rows($result) > 0){
        $output .= "<td><select name='id_cititor'><option value='neales'>".' '."</option>";
          while($row = mysqli_fetch_array($result)){
            $output .=  "<option value=".$row['id_cititor'].">".$row['nume_concatenat']."</option>";
          }
          $output .=  "</select></td>";
          mysqli_free_result($result);// Free result set
      }} 


      $sql = 'SELECT id_carte, titlu FROM CARTE';
      echo_sql($sql,false);
      if($result = mysqli_query($link, $sql)){
        if(mysqli_num_rows($result) > 0){
          $output .= "<td><select name='id_carte'><option value='neales'>".' '."</option>";
            while($row = mysqli_fetch_array($result)){
              $output .=  "<option value=".$row['id_carte'].">".$row['titlu']."</option>";
            }
            $output .=  "</select></td>";
            mysqli_free_result($result);// Free result set
        }} 

  $output .="</tr></table><center><input type='submit' value='Introdu imprumutul in baza de date'></center></form><br><br>";


  if (!empty($_REQUEST)){
    $text_popup = "";
    $erori = 0;
    $sql = '';
    $data_imprumut = $_REQUEST['data_imprumut'];
    $durata_imprumut = $_REQUEST['durata_imprumut'];
    $id_cititor = $_REQUEST['id_cititor'];
    $id_carte = $_REQUEST['id_carte'];

    if (strlen($data_imprumut) != 10){
      $text_popup .= '- nu ai introdus data in formatul valid;\n';
      $erori++;
    }
    if (strlen($durata_imprumut) == 0 or !is_numeric($durata_imprumut)){
      $text_popup .= '- durata imprumutului trebuie sa fie compusa din cifre;\n';
      $erori++;
    }

    if ($id_cititor == 'neales'){
      $text_popup .= '- nu ai ales cititorul;\n';
      $erori++;
    }

    if ($id_carte == 'neales'){
      $text_popup .= '- nu ai ales cartea;\n';
      $erori++;
    }

    if ($erori != 0){
      $text_popup = 'Cititorul nu a putut fi introdus in baza de date deoarece:\n'.$text_popup;
    } else {
      $sql = "INSERT INTO imprumut VALUES (default,'{$data_imprumut}',$durata_imprumut,$id_cititor,$id_carte);";
      echo_sql($sql,false);
      if($result = mysqli_query($link, $sql)){
        if($result){
          $text_popup .= 'Imprumutul cartii a fost introdus cu succes in baza de date';
        }} 
    }
    $output .= popup($text_popup);
  }
  $output .= "</body></html>";
  deconectare();
}

echo $output;